<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/9/5
 * Time: 14:26
 */

return[
    //商品类型
    'good_type'=>[
        [
            'key' => 'office',
            'name' => '办公',
        ],
        [
            'key' => 'car',
            'name' => '车用',
        ],
    ],
    'wms_order_type' =>[
		[
			'key' => 'preentry',
			'name' => '入库',
		],
		[
			'key' => 'movein',
			'name' => '移库入',
		],
        [
            'key' => 'moveout',
            'name' => '移库出',
        ],
        [
            'key' => 'change',
            'name' => '修改差异',
        ],
		[
            'key' => 'out',
            'name' => '出库',
        ],
    ],

    //费用类型
    'wms_cost_type' =>[
		[
			'key' => 'pull',
			'name' => '托（个）',
		],
		[
			'key' => 'weight',
			'name' => '重量（KG）',
		],
		[
			'key' => 'bulk',
			'name' => '体积（立方）',
		],
        [
            	'key' => 'no',
            	'name' => '不收费',
        ],
    ],

    //费用类型
    'wms_money_type' =>[
        [
            'key' => 'in',
            'name' => '入库费',
        ],
        [
            'key' => 'out',
            'name' => '出库费',
        ],
        [
            'key' => 'storage',
            'name' => '仓储费',
        ],
        [
            'key' => 'total',
            'name' => '分拣费',
        ],
    ],

    //时间类型
    'period' =>[
        [
            'key' => 'day',
            'name' => '天',
        ],
        [
            'key' => 'month',
            'name' => '月',
        ],
        [
            'key' => 'year',
            'name' => '年',
        ],
    ],

    //入库状态
    'in_store_status' =>[
        [
            'key' => 'normal',
            'name'=> '正常入库'
        ],
        [
            'key' => 'profit',
            'name'=> '盘盈入库'
        ],
        [
            'key' => 'return',
            'name'=> '退货入库'
        ],
        [
            'key' => 'process',
            'name'=> '加工入库'
        ],
        [
            'key' => 'transfer',
            'name'=> '移库入库'
        ],
        [
            'key' => 'cargo',
            'name'=> '货权转移'
        ],
        [
            'key' => 'b2c',
            'name'=> 'B2C入库'
        ],
        [
            'key' => 'fast',
            'name'=> '快进快出'
        ]
    ],
    //上架类型
    'grounding_type'=>[
        [
            'key'=>'normal',
            'name'=>'正常上架'
        ],
        [
            'key'=>'bulk',
            'name'=>'零担'
        ],
        [
            'key'=>'grounding',
            'name'=>'零担上架'
        ]
    ],
    //出库状态
    'out_store_status' =>[
        [
            'key' => 'normal',
            'name'=> '正常出库'
        ],
        [
            'key' => 'profit',
            'name'=> '盘盈出库'
        ],
        [
            'key' => 'return',
            'name'=> '退货出库'
        ],
        [
            'key' => 'process',
            'name'=> '加工出库'
        ],
        [
            'key' => 'transfer',
            'name'=> '移库出库'
        ],
        [
            'key' => 'cargo',
            'name'=> '货权转移'
        ],
        [
            'key' => 'b2c',
            'name'=> 'B2C出库'
        ],
        [
            'key' => 'fast',
            'name'=> '快进快出'
        ]
    ],



]
?>
