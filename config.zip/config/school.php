<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/9/5
 * Time: 14:26
 */

return[
    //职员角色
    'person_type' =>[
        [
            'key' => 'driver',
            'name' => '司机',
        ],
        [
            'key' => 'patriarch',
            'name' => '家长',
        ],
        [
            'key' => 'care',
            'name' => '照管员',
        ],
        [
            'key' => 'student',
            'name' => '学生',
        ],
        [
            'key' => 'teacher',
            'name' => '老师',
        ],

    ],

//收费管理
    'cost_type' =>[
        [
            'key' => 'month',
            'name' => '月',
        ],
        [
            'key' => 'week',
            'name' => '周',
        ],

    ],



]
?>
