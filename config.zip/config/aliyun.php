<?php
/**
 * 参数设置中心

 */
return[
    //阿里云图片配置文件
    'oss' => [
        'driver'        => 'oss',
        'access_id'     => 'LTAI4GABQN6bKEV5o33eVk8V',
        'access_key'    => 'EpzuQsYDRc4qmdKGABkqmI8zKlkHki',
        'endpoint'      => 'http://oss-cn-beijing.aliyuncs.com',//你的阿里云OSS地址
        'bucket'        => 'chitull',
        'city'          =>'北京',
        'url'		    =>'https://chitull.oss-cn-beijing.aliyuncs.com/',
        'url_len'	    =>'44',
    ],

    //短信模板中心
	'aliyun'=>[
        'accessKeyId'		=>'LTAI4GKcLBk4vrh9rs3tfsNf',
        'accessKeySecret'	=>'MVcqsj67uSNdT81YOH7lU12h9e7Nfm',
        'SignName'          =>'得宝拍',
    ],


    $abc='https://bloodcity.oss-cn-beijing.aliyuncs.com/',
    'group'=>[
        'group_name'=>'大鼻子校车',
        /** 线路未开始和已结束的图 */
        'start_img'=>$abc.'images/2020-05-21/bd6817c6e0bd9c042926898e3db79af0.jpg',
        'end_img'=>$abc.'images/2020-06-03/d01ffd9119e2e2738591c3447638ad17.jpg',

        /** 分享后打开页面上部的控制信息 */
        'care_flag'=>'Y',
        'care_tel_flag'=>'N',
        'school_img'=>$abc.'images/2020-06-15/8f9480a23a938667bc698465c7d5adc6.png',
        'path_img'=>$abc.'images/2020-06-02/5e1d59b032b93495c4f045dc2e312a03.png',
        'care_img'=>$abc.'images/2020-06-02/8f550117d15ec76fab9a63b57a13f4c3.png',
        'identity'=>'照管员',

        /** 分享后打开页面右部的控制信息 */
        'location_flag'=>'N',
        'fen_flag'=>'N',
        'location_img'=>$abc.'images/2020-06-02/cc9a886224e5bc83b760f9e689514729.png',
        'fen_img'=>$abc.'images/2020-06-02/dd3585156fc920fcb9cee5374d89b1bb.png',

        /** 分享后打开页面地图上的图标显示 */
        'move_img'=>$abc.'images/2020-05-28/220bb10f5fdfd58aca00590e9a54bd49.png',
        'icon_img'=>$abc.'images/2020-06-02/323bceff54c42884e9deb84e32dfdd83.png',

        /** 分享的文字和图片 */
        'share_title'=>'大鼻子校车',
        'share_img'=>$abc.'images/2020-06-15/3b05106de340bb18268f8ba6ed858539.png',

    ],
]


?>
