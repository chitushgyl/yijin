<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/9/5
 * Time: 14:26
 */

return[
    //商品类型
    'good_type' =>[
		[
			'key' => 'o2o',
			'name' => '配送商品',
		],
		[
			'key' => 'stock',
			'name' => '股权商品',
		],
    ],


    //标签类型
    'label_flag' =>[
		[
			'key' => 'text',
			'name' => '文字类型',
		],
		[
			'key' => 'img',
			'name' => '图片类型',
		],
		[
			'key' => 'no',
			'name' => '无标签',
		],
    ],

    //产品状态
    'good_status' =>[
		[
			'key' => 'Y',
			'name' => '上架',
		],
		[
			'key' => 'N',
			'name' => '下架',
		],
		[
			'key' => 'Q',
			'name' => '永久下架',
		],
    ],

    //配送模式
    'delivery_type' =>[
		[
			'key' => 'city',
			'name' => '全城',
		],
		[
			'key' => 'range',
			'name' => '商圈',
		],
		[
			'key' => 'all',
			'name' => '全部支持',
		],
    ],

    //价格显示
    'price_show_flag' =>[
		[
			'key' => 'A',
			'name' => '单个最低价格',
		],
		[
			'key' => 'Q',
			'name' => '区间价格',
		],
    ],

    //库存类型
     'sku_flag' =>[
		[
			'key' => 'D',
			'name' => '每个SKU单独计算',
		],
		[
			'key' => 'T',
			'name' => '所有SKU计算',
		],
    ],
    //购物车显示情况
     'cart_show' =>[
		[
			'key' => 'all',
			'name' => '购物车、立即购买',
		],
		[
			'key' => 'cart',
			'name' => '购物车',
		],
		[
			'key' => 'alone',
			'name' => '立即购买',
		],
     ],



    //模板类型
	'home_template' =>[
		[
			'key' => 'search',
			'name' => '商品搜索',
			'must'=>['name'],
		],
        [
            'key' => 'search_group',
            'name' => '门店搜索',
            'must'=>['name'],
        ],
		[
			'key' => 'lunbo',
			'name' => '轮播',
            'must'=>['url'],
		],
		[
			'key' => 'wulan',
			'name' => '五栏位小入口',
            'must'=>['url','name'],
		],
		[
			'key' => 'lianglan',
			'name' => '两栏广告位',
            'must'=>['url'],
		],
		[
			'key' => 'yilan',
			'name' => '一栏广告位',
            'must'=>['url'],
		],
		[
			'key' => 'home_menu',
			'name' => '二级菜单目录',
            'must'=>['name'],
		],
    ],

    //操作类型
    'jump' =>[
		[
			'key' => 'good',
			'name' => '指定商品',
		],
		[
			'key' => 'shop',
			'name' => '指定门店',
		],[
			'key' => 'classify',
			'name' => '指定分类',
		],
		[
			'key' => 'web',
			'name' => 'WEB跳转',
		],
		[
			'key' => 'N',
			'name' => '不跳转',
		],
    ],


        //快递
    'deliver_company' =>[
		[	
			'key'=>'1',
			'name'=>'顺丰快递',
		],
		[	
			'key'=>'2',
			'name'=>'圆通快递',
		],
		[	
			'key'=>'3',
			'name'=>'韵达快递',
		],
		[	
			'key'=>'4',
			'name'=>'天天快递',
		],
		
    ],
    //领取优惠券状态
    'get_way' =>[
		[
			'key' => 'common',
			'name' => '首页领取',
		],
		[
			'key' => 'late',
			'name' => '迟到',
		],
		[
			'key' => 'web',
			'name' => '页面领取',
		],
		[
			'key' => 'integral',
			'name' => '积分兑换',
		],
		[
			'key' => 'exchange',
			'name' => '兑换码兑换',
		],
		[
			'key' => 'activity',
			'name' => '活动详情',
		],
    ],


    'coupon_type' =>[
		[
			'key' => 'all',
			'name' => '全场券',
		],
		[
			'key' => 'good',
			'name' => '单品券',
		],
    ],


    'coupon_state' =>[
        [
            'key' => 'wait',
            'name' => '未开始',
        ],
        [
            'key' => 'process',
            'name' => '进行中',
        ],
        [
            'key' => 'over',
            'name' => '已结束',
        ],
    ],

    'pay_status' =>[
        [	'key' => '1',
            'pay_status_color' => '#FF0000',
            'pay_status_text' => '待支付',		 ],

        [	'key' => '2',
            'pay_status_color' => '#43CD80',
            'pay_status_text' => '已支付',		 ],

        [	'key' => '3',
            'pay_status_color' => '#7B68EE',
            'pay_status_text' => '已发货',		 ],

        [	'key' => '4',
            'pay_status_color' => '#4B0082',
            'pay_status_text' => '已完成',		 ],

        [	'key' => '5',
            'pay_status_color' => '#FF0000',
            'pay_status_text' => '已取消',		 ],

        [	'key' => '6',
            'pay_status_color' => '#FF0000',
            'pay_status_text' => '已退款',		 ],

        [	'key' => '7',
            'pay_status_color' => '#0A0A0A',
            'pay_status_text' => '已评价',		 ],

        [	'key' => '8',
            'pay_status_color' => '#0A0A0A',
            'pay_status_text' => '已关闭',		 ],

        [	'key' => '9',
            'pay_status_color' => '#0A0A0A',
            'pay_status_text' => '已送达',		 ],

    ],




]
?>
