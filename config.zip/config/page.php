<?php
/**
 * 参数设置中心

 */
return[
    //每页加载数量
    'listrows'=>['30','50','100','500','1000','2000','3000'],
	
	'listrows2'=>['5','10','20',],

     'platform'=>[
        'front_name'		=>'front.56cold.com',
        'app_id'	        =>'wxdc3dff8cfd3db5cb',
        'secret'		    =>'39f8bfcfd099af3ede363af5355d7d6d',
//	'app_id'	        =>'wxe83015a059e35239',
//	'secret'		    =>'5f87e86d1bfd0bb07a90ce7f0845b7cc',
        'group_code'		=>'1234',
        'notify_url'		=>'http://api.56cold.com/notify/notify',
    ],
	
	'smallRoutine'=>[
		//大鼻子
		//'appId'=>'wx6e301696cc179a6b',
		//'appSecret'=>'42838b474d9c5e788e974ba8c63a7af8',
		//小鼻子 
//		'appId'=>'wxa6943701bf367e90',
//		'appSecret'=>'216389fadda766ef605be2c6c9cde344',
		'appId'=>'wxe83015a059e35239',
		'appSecret'=>'5f87e86d1bfd0bb07a90ce7f0845b7cc'
	],

    //公司权限类型11
    'business_type' =>[
//        [   'key' => 'SHOP',
//            'name' => '商城',   ],
//
//        [   'key' => 'SCHOOL',
//            'name' => '校车',   ],
	   
//	    [   'key' => 'TMS2',
//            'name' => '3PL货主',   ],

		[   'key' => 'TMS',
            'name' => 'TMS系统',   ],

	    [   'key' => 'WMS',
            'name' => 'WMS系统',   ],

	    [   'key' => 'FULL',
            'name' => '所有',   ],
	   
    ],

//操作类型
    'operation_type' =>[
        [   'key' => 'create',
            'name' => '创建',   ],

        [   'key' => 'update',
            'name' => '修改',   ],

        [   'key' => 'use_flag',
            'name' => '启禁用',   ],

        [   'key' => 'del_flag',
            'name' => '删除',   ],

        [   'key' => 'sort',
            'name' => '排序',   ],

        [   'key' => 'batch',
            'name' => '批量',   ],

        [   'key' => 'status_change',
            'name' => '上下架',   ],
    ],

	'remove_url'=>[
        '/cart',
        '/address/address',
        '/address/create_address',
        '/cart/cart',
        '/collect/index',
        '/coupon/index',
        '/integral/index',
        '/order/index',
        '/wallet/index'
    ],
	
	
	    //微信推送固定人群
	'wx_push' =>[
        '0'=>[
            'token_id'=>'o-QhFwfq1JXqj-Q0vmtiNJaDgEwI',
            'token_name'=>'疍瑆',
            'person_name'=>'疍瑆',
        ],
        '1'=>[
            'token_id'=>'o-QhFwbdGUeooL-OnN0WqjJ0Fcl0',
            'token_name'=>'吉安',
            'person_name'=>'吉安',
        ],
		'2'=>[
            'token_id'=>'o-QhFwVHKCOXbtyP8BvsyUqJ4wuI',
            'token_name'=>'正年',
            'person_name'=>'正年',
        ],
    ],

    'rule'=>[
        'catalog/summary'=>'大分类页面',
        'catalog/category'=>'小分类页面',
        'home/index'=>'首页',
        'holidy/patriarch_get_holidy'=>'家长获取请假数据',
        'trips/ride_status'=>'手动到站',
        'trips/carriage'=>'用户访问实时轨迹',
        'trips/trips'=>'手动发车',
        'student/get_child'=>'学生列表',
        'student/add_child'=>'绑定学生',
        'index/patriarch'=>'家长首页',
        'index/teacher'=>'老师首页',
        'index/care'=>'照管员首页',
        'holidy/patriarch_add_holidy'=>'家长操作请假',
        'index/capture'=>'小程序修正站点',
        'index/invite'=>'照管员身份绑定(邀请码)',
        'trips/path_loglat'=>'家长端实时获取线路的经纬度',

    ],



]


?>
