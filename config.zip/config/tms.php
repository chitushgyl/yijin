<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/9/5
 * Time: 14:26
 */

return[
    //罐体介质
    'crock_medium' =>[
//        [
//            'key' => 'sulphur',
//            'name' => '硫磺',
//        ],
        [
            'key' => 'transfer',
            'name' => '仓配一体型',
        ],
    ],
 /**人员类型**/
    'user_type' => [
        [
            'key' => 'driver',
            'name'=> '驾驶员'
        ],
        [
            'key' => 'cargo',
            'name'=> '押运员'
        ],
        [
            'key' => 'dr_cargo',
            'name'=> '驾驶员/押运员'
        ],
        [
            'key' => 'manager',
            'name'=> '管理人员'
        ],
    ],
     /***维修保养类型**/
    'service_type' => [
        [
            'key' => 'service',
            'name'=> '维修'
        ],
        [
            'key' => 'preserve',
            'name'=> '保养'
        ],
    ],
     /***学历分类**/
    'background' => [
        [
            'key' => '1',
            'name'=> '不限'
        ],
        [
            'key' => '2',
            'name'=> '初中及以下'
        ],
        [
            'key' => '3',
            'name'=> '中专/中技'
        ],
        [
            'key' => '4',
            'name'=> '高中'
        ],
        [
            'key' => '5',
            'name'=> '大专'
        ],
        [
            'key' => '6',
            'name'=> '本科'
        ],
        [
            'key' => '7',
            'name'=> '硕士'
        ],
        [
            'key' => '8',
            'name'=> '博士'
        ],
    ],
     /***客户类型**/
    'company_type' => [
        [
            'key' => 'take',
            'name'=> '收货人'
        ],
        [
            'key' => 'load',
            'name'=> '装货人'
        ],
        [
            'key' => 'check',
            'name'=> '托运人'
        ],
    ],
    /**货物类型**/
    'wares_type' => [
        [
            'key' => 1,
            'name'=> 3
        ],
        [
            'key' => 2,
            'name'=> 4.1
        ],
        [
            'key' => 3,
            'name'=> 5.1
        ],
        [
            'key' => 4,
            'name'=> 5.2
        ],
        [
            'key' => 5,
            'name'=> 6.1
        ],
        [
            'key' => 6,
            'name'=> 8
        ],
        [
            'key' => 7,
            'name'=> 9
        ],
        [
            'key' => 10,
            'name'=> '危险废物'
        ],
    ],
   //费用类型
    'money_type' => [
        [
            'key' => 'freight',
            'name'=> '运费'
        ],
        [
            'key' => 'road',
            'name'=> '过路费'
        ],
        [
            'key' => 'fuel',
            'name'=> '油费'
        ],
        [
            'key' => 'repair',
            'name'=> '维修费'
        ],
        [
            'key' => 'preserve',
            'name'=> '保养费'
        ],
        [
            'key' => 'incidental',
            'name'=> '杂费'
        ],
        [
            'key' => 'salary',
            'name'=> '工资'
        ],
        [
            'key' => 'reward',
            'name'=> '奖惩费'
        ],
        [
            'key' => 'reimbur',
            'name'=> '报销'
        ],
        [
            'key' => 'other',
            'name'=> '其他'
        ],
        [
            'key' => 'delivery_fee',
            'name'=> '领用费'
        ],
        [
            'key' => 'trye',
            'name'=> '轮胎费'
        ],

    ],
    'order_type' => [
        [
            'key' => 1,
            'name'=> '待调度'
        ],
        [
            'key' => 2,
            'name'=> '已调度'
        ],
        [
            'key' => 3,
            'name'=> '已装货'
        ],
        [
            'key' => 4,
            'name'=> '运输中'
        ],
        [
            'key' => 5,
            'name'=> '已卸货'
        ],
        [
            'key' => 6,
            'name'=> '已签收'
        ],
        [
            'key' => 7,
            'name'=> '已取消'
        ],
    ],

    'order_log_type' => [
        [
            'key' => 1,
            'name'=> '创建运单'
        ],
        [
            'key' => 2,
            'name'=> '调度车辆'
        ],
        [
            'key' => 3,
            'name'=> '装货完成'
        ],
        [
            'key' => 4,
            'name'=> '发车'
        ],
        [
            'key' => 5,
            'name'=> '到达'
        ],
        [
            'key' => 6,
            'name'=> '卸货完成'
        ],
        [
            'key' => 7,
            'name'=> '签收'
         ],
    ],

        //部门
    'department_type' => [
        [
            'key' => 1,
            'name'=> '运管'
        ],
        [
            'key' => 2,
            'name'=> '交警'
        ],
        [
            'key' => 3,
            'name'=> '高速交警'
        ],

    ],
    'account_type' =>[
        [
            'key' => 'Alipay',
            'name' => '支付宝',
            'url'=>'2020-07/ali_type.png'
        ],
        [
            'key' => 'Bank',
            'name' => '银行卡',
            'url'=>'2020-07/bank_type.png'
        ]
    ],
    /** 开票抬头类型***/
    'tax_type' =>[
        [
            'key' => 'company',
            'name' => '企业',
        ],
        [
            'key' => 'personal',
            'name' => '个人/非企业',
        ]
    ],
    'bill_type' =>[
        [
            'key' => 'normal',
            'name' => '普票',
        ],
        [
            'key' => 'special',
            'name' => '专用发票',
        ]
    ],


    //    后台公司类型
    'tms_company_type' =>[
        [
            'key' => 'TMS3PL',
            'name' => '3PL公司',
        ],
        [
            'key' => 'company',
            'name' => '货主公司',
        ],
    ],


    //调度类型
    'tms_dispatch_type' =>[
        [
            'key' => '1',
            'dispatch_status_color' => '#7B68EE',
            'name' => '未调度',
        ],
        [
            'key' => '2',
            'dispatch_status_color' => '#7B68EE',
            'name' => '已调度',
        ]
    ],
    //上线类型
    'tms_online_type' =>[
        [
            'key' => '1',
            'online_status_color' => '#7B68EE',
            'name' => '已上线',
        ],
        [
            'key' => '2',
            'online_status_color' => '#7B68EE',
            'name' => '未上线',
        ]
    ],



    //tms订单状态类型
    'tms_order_status_type' =>[
        [	'key' => '1',
            'pay_status_color' => '#FF0000',
            'pay_status_text' => '未支付',   ],

        [	'key' => '2',
            'pay_status_color' => '#43CD80',
            'pay_status_text' => '未接单',		 ],

        [	'key' => '3',
            'pay_status_color' => '#7B68EE',
            'pay_status_text' => '已接单',		 ],

        [	'key' => '4',
            'pay_status_color' => '#4B0082',
            'pay_status_text' => '已调度',		 ],

        [	'key' => '5',
            'pay_status_color' => '#FF0000',
            'pay_status_text' => '已送达',		 ],

        [	'key' => '6',
            'pay_status_color' => '#FF0000',
            'pay_status_text' => '已完成',		 ],

        [	'key' => '7',
            'pay_status_color' => '#0A0A0A',
            'pay_status_text' => '已取消',		 ],
    ],

'tms_order_status' =>[
    [	'key' => '1',
        'pay_status_color' => '#FF0000',
        'pay_status_text' => '未接单',   ],

    [	'key' => '2',
        'pay_status_color' => '#43CD80',
        'pay_status_text' => '已接单',		 ],


    [	'key' => '3',
        'pay_status_color' => '#4B0082',
        'pay_status_text' => '运输中',		 ],

    [	'key' => '4',
        'pay_status_color' => '#FF0000',
        'pay_status_text' => '已完成',		 ],

    [	'key' => '5',
        'pay_status_color' => '#FF0000',
        'pay_status_text' => '已取消',		 ],


],

    //tms费用类型
    'tms_money_type' =>[
        [
            'key' => 'freight',
            'name' => '运费',
        ],
        [
            'key' => 'loading',
            'name' => '装货费',
        ],
        [
            'key' => 'unloading',
            'name' => '卸货费',
        ],
        [
            'key' => 'gather',
            'name' => '提货费',
        ],
        [
            'key' => 'send',
            'name' => '配送费',
        ],[
            'key' => 'more',
            'name' => '多点费用',
        ],
        [
            'key' => 'other',
            'name' => '其他费用',
        ],

    ],

    //tms结算方式
    'tms_cost_type' =>[
        [	'key' => 'monthly',
            'name' => '月结',   ],

        [	'key' => 'weeks',
            'name' => '周结',		 ],

        [	'key' => 'day',
            'name' => '日结',		 ],

        [	'key' => 'nowPay',
            'name' => '现付',		 ],

    ],

    //tms钱包流水类型
    'tms_wallet_info' =>[
        [   'key' => 'in',
            'name' => '收入',
            'image'=>'2020-07/takeOrder.png'
            ],

        [   'key' => 'out',
            'name' => '支付',
            'image'=>'2020-07/addOrder.png'
            ],

        [   'key' => 'ti',
            'name' => '提现',
            'image'=>'2020-07/withdraw.png'
            ],

        [   'key' => 'recharge',
            'name' => '充值',
            'image'=>'2020-07/depist.png'
            ],

        [   'key' => 'refund',
            'name' => '退款',
            'image'=>'2020-07/refund.png'
            ],

    ],

    //tms钱包流水类型
    'tms_wallet_status' =>[
        [   'key' => 'SU',
            'name' => '成功',
            'image' => '2020-07/attestation_su.png'           ],


        [   'key' => 'WAIT',
            'name' => '等待中',
            'image' => '2020-07/attestation_wait.png'           ],

        [   'key' => 'FS',
            'name' => '失败',
            'image' => '2020-07/attestation_fail.png'           ],

    ],

    'tms_settle_type' =>[
        [   'key' => 'GROUP_CODE',
            'name' => '公司',   ],

        [   'key' => 'USER',
            'name' => '用户',],

        [   'key' => 'PLATFORM',
            'name' => '平台', ],

        [   'key' => 'DRIVER',
            'name' => '司机', ],
        [   'key' => 'COMPANY',
            'name' => '货主公司', ],
    ],

    'tms_login_type' =>[
        [   'key' => 'after',
            'name' => 'PC系统',   ],

        [   'key' => 'H5',
            'name' => '微信公众号',],

    ],

    'order_state_type' => [
        [
            'name'=>'待接单',
            'type'=>'status2'
        ],
        [
            'name'=>'运输中',
            'type'=>'status3'
        ],
        [
            'name'=>'已完成',
            'type'=>'status6'
        ],
        [
            'name'=>'已取消',
            'type'=>'status7'
        ]
    ],
    'take_state_type' =>[
        [
            'name'=>'待调度',
            'type'=>'status1'
        ],
        [
            'name'=>'进行中',
            'type'=>'status2'
        ],
        [
            'name'=>'已完成',
            'type'=>'status3'
        ],
    ],
    '3pl_order_state'=>[
        [
            'name'=>'待接单',
            'type'=>'status6'
        ],
        [
            'name'=>'待调度',
            'type'=>'status1'
        ],
        [
            'name'=>'进行中',
            'type'=>'status2'
        ],
        [
            'name'=>'已完成',
            'type'=>'status3'
        ],
        [
            'name'=>'已取消',
            'type'=>'status4'
        ]
    ],
    '3pl_dispatch_state'=>[
        [
            'name'=>'待调度',
            'type'=>'status1'
        ],
        [
            'name'=>'进行中',
            'type'=>'status2'
        ],
        [
            'name'=>'已完成',
            'type'=>'status3'
        ]
    ],

  ]
?>
